import type { TaskAwareProjectContext } from "../scanner/taskAwareContextScanner.js";

interface ProjectLike {
    name: string;
    localPath?: string;
    packageManager?: string | null;
    detectedStack?: string[];
    scripts?: Record<string, string>;
    readinessScore?: number;
}

interface BuildAgentsEnhancementPromptInput {
    project: ProjectLike;
    templateMarkdown: string;
}

interface BuildTaskPackEnhancementPromptInput {
    project: ProjectLike;
    templatePrompt: string;
    rawTask: string;
    taskType: string;
    targetTool: string;
    projectContext?: TaskAwareProjectContext;
}

function formatJson(value: unknown) {
    return JSON.stringify(value, null, 2);
}

function getTargetToolLabel(targetTool: string) {
    const labels: Record<string, string> = {
        codex: "Codex",
        cursor: "Cursor",
        claude: "Claude Code",
        gemini: "Gemini",
        generic: "Generic AI Agent"
    };

    return labels[targetTool] ?? targetTool;
}

function getTaskTypeLabel(taskType: string) {
    const labels: Record<string, string> = {
        general: "General",
        ui: "UI / UX",
        backend: "Backend",
        bugfix: "Bugfix",
        refactor: "Refactor",
        docs: "Docs",
        tests: "Tests"
    };

    return labels[taskType] ?? taskType;
}

export function buildAgentsEnhancementPrompt({
    project,
    templateMarkdown
}: BuildAgentsEnhancementPromptInput) {
    return `
You are ContextForge's local AI generation engine.

Your job:
Improve an AGENTS.md file for AI coding agents.

Output contract:
- Output the final AGENTS.md content only.
- The first line must be exactly: # AGENTS.md
- Do not write introductions like "Here is", "Sure", or "Below is".
- Do not write final notes, explanations, disclaimers, or commentary after the document.
- Do not wrap the answer in code fences.
- Do not output a table of contents.
- Do not output an empty outline of headings.
- Each required section must contain useful content.
- Use Markdown only.
- Preserve factual project information.
- Do not invent technologies, scripts, files, APIs, folders, dependencies, or architecture.
- If information is missing, write cautious notes instead of inventing details.
- Keep the document concise, practical, and useful for AI coding agents.
- Prefer direct instructions over generic advice.
- Add a short "ContextForge Assisted Notes" section with project-specific advice.
- Keep existing project rules strict and review-friendly.
- Do not remove important warnings from the template.
- If the template contains a "Project Memory / Decision Log" section, preserve it and its saved decisions exactly.

Required document structure:
# AGENTS.md
## Project Overview
## Available Commands
## Recommended Workflow for AI Agents
## Verification Commands
## Project Rules
## Project Memory / Decision Log (only if present in the template)
## AI Readiness Issues
## ContextForge Assisted Notes
## Output Expectations

Project metadata:
${formatJson({
        name: project.name,
        localPath: project.localPath,
        packageManager: project.packageManager,
        detectedStack: project.detectedStack,
        scripts: project.scripts,
        readinessScore: project.readinessScore
    })}

Template AGENTS.md:
${templateMarkdown}
`.trim();
}


export function buildTaskPackEnhancementPrompt({
    project,
    templatePrompt,
    rawTask,
    taskType,
    targetTool,
    projectContext
}: BuildTaskPackEnhancementPromptInput) {
    const targetToolLabel = getTargetToolLabel(targetTool);
    const taskTypeLabel = getTaskTypeLabel(taskType);
    const hasTestScript = Boolean(project.scripts?.test);

    return `
You are ContextForge's local AI generation engine.

Your job:
Improve a task pack prompt for an AI coding agent.

Output contract:
- Output the final task pack prompt only.
- The first line must be exactly: # AI Task Pack
- Do not write introductions like "Here is", "Sure", or "Below is".
- Do not write final notes, explanations, disclaimers, or commentary after the prompt.
- Do not output a table of contents.
- Do not output an empty outline of headings.
- Each required section must contain useful content.
- Do not wrap the answer in code fences.
- Use Markdown only.
- Preserve the user's actual task.
- The "ContextForge Assisted Notes" section must use the exact heading: ## ContextForge Assisted Notes
- Do not invent project files, APIs, scripts, folders, dependencies, or implementation details.
- Do not recommend npm scripts that are not present in project metadata.
- ${hasTestScript
            ? "The project has a test script. You may include it in verification."
            : "The project has no detected test script. Do not recommend npm run test."
        }
- Use the task-aware project context to make the prompt more specific.
- Mention relevant file candidates when useful.
- Use file snippets to understand architecture, but do not overfit to partial code.
- Mention likely relevant files based on both file paths and snippets.
- If snippets are incomplete or truncated, tell the coding agent to inspect the full files before editing.
- Do not claim that a file definitely must be edited unless the context strongly suggests it.
- Tell the coding agent to inspect relevant files before modifying them.
- Make the prompt more actionable for ${targetToolLabel}.
- Make acceptance criteria clear and specific.
- Make verification steps practical.
- Keep the prompt structured, concise, and copy-ready.
- Avoid generic filler.
- Add a short "ContextForge Assisted Notes" section with project-specific advice.

Required document structure:
# AI Task Pack
## Target Tool
## Task Type
## Task
## Project Context
## Relevant File Candidates
## Agent Instructions
## Constraints
## Known AI-Readiness Issues
## Acceptance Criteria
## Verification
## ContextForge Assisted Notes
## Expected Final Response

Target tool display name:
${targetToolLabel}

Task type display name:
${taskTypeLabel}

Project metadata:
${formatJson({
            name: project.name,
            localPath: project.localPath,
            packageManager: project.packageManager,
            detectedStack: project.detectedStack,
            scripts: project.scripts,
            readinessScore: project.readinessScore
        })}

Task-aware project context:
${formatJson({
            taskType: projectContext?.taskType,
            taskIntent: projectContext?.taskIntent,
            projectTree: projectContext?.projectTree,
            relevantFiles: projectContext?.relevantFiles,
            fileSnippets: projectContext?.fileSnippets,
            notes: projectContext?.notes
        })}

User task:
${rawTask}

Template task pack:
${templatePrompt}
`.trim();
}
